"""EDIT ME: the models. Every model has the same two steps:

    model.fit(train)        train = past sales, including sold_price and date_sold
    model.predict(homes)    homes = homes to value, with only the columns of a test file;
                            returns one predicted sold price per home

make_model() picks the model for each track. The two starting models are baselines:
deliberately simple, so you can measure how much your own ideas add.
"""
import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

import features


def make_model(track):
    """Return a fresh, untrained model for "off_market" or "list_aware"."""
    if track == "list_aware":
        return RatioModel(features.list_aware_features)
    if track == "off_market":
        return FeatureModel(features.off_market_features)
    raise ValueError(f"Unknown track: {track}")


class ListPriceBaseline:
    """List-aware baseline: every home sells for exactly its list price."""

    def fit(self, train):
        return self   # nothing to learn

    def predict(self, homes):
        return homes["list_price"].to_numpy(dtype=float)


class NearestSalesBaseline:
    """Off-market baseline: the median sold price of the k nearest earlier sales of
    the same property type.

    "Nearest" means closest by latitude and longitude. "Earlier" means sold before the
    home was listed, so the model never looks into the future, even when the
    training table holds later sales. It makes no adjustment for size, condition or
    for prices moving since those sales: improving on that is your job.
    """

    def __init__(self, k=10):
        self.k = k

    def fit(self, train):
        columns = ["ml_num", "house_type_name", "date_sold", "latitude", "longitude", "sold_price"]
        # Newest sales first, so when several sales are equally near (a condo
        # building shares one location), the most recent ones are picked.
        self.sales = train[columns].sort_values(["date_sold", "ml_num"], ascending=[False, True])
        self.sales_by_type = dict(list(self.sales.groupby("house_type_name")))
        return self

    def predict(self, homes):
        return np.array([self.predict_one(home) for _, home in homes.iterrows()])

    def predict_one(self, home):
        sales = self.sales_by_type.get(home["house_type_name"], self.sales)
        earlier = sales[sales["date_sold"] < home["date_listed"]]
        if len(earlier) == 0:   # no earlier sale of this type: use every type
            earlier = self.sales[self.sales["date_sold"] < home["date_listed"]]

        # Distance in degrees. In Toronto a degree of longitude is only 0.72 times as
        # long as a degree of latitude (0.72 = cosine of 43.7 degrees north).
        dx = (earlier["longitude"].to_numpy() - home["longitude"]) * 0.72
        dy = earlier["latitude"].to_numpy() - home["latitude"]
        distance = np.sqrt(dx ** 2 + dy ** 2)

        nearest = np.argsort(distance, kind="stable")[: self.k]
        return float(np.median(earlier["sold_price"].to_numpy()[nearest]))


class FeatureModel:
    """Gradient-boosted trees that can also read text columns (garage, neighbourhood)."""

    def __init__(self, make_features):
        self.make_features = make_features
        self.model = HistGradientBoostingRegressor(
            random_state=0, categorical_features="from_dtype")
        self.categories = {}

    def fit(self, train):
        X = self.make_features(train)
        self.categories = {}
        for column in X.columns:
            if str(X[column].dtype) in ("object", "category"):
                X[column] = X[column].astype("category")
                self.categories[column] = list(X[column].cat.categories)
        self.model.fit(X, np.log(train["sold_price"]))
        return self

    def predict(self, homes):
        X = self.make_features(homes)
        for column, cats in self.categories.items():
            X[column] = pd.Categorical(X[column], categories=cats)
        return np.exp(self.model.predict(X))


class RatioModel(FeatureModel):
    """Predicts how far above or below asking a home sells, then multiplies by the list price."""

    def fit(self, train):
        X = self.make_features(train)
        self.categories = {}
        for column in X.columns:
            if str(X[column].dtype) in ("object", "category"):
                X[column] = X[column].astype("category")
                self.categories[column] = list(X[column].cat.categories)
        self.model.fit(X, np.log(train["sold_price"] / train["list_price"]))
        return self

    def predict(self, homes):
        X = self.make_features(homes)
        for column, cats in self.categories.items():
            X[column] = pd.Categorical(X[column], categories=cats)
        return homes["list_price"].to_numpy() * np.exp(self.model.predict(X))